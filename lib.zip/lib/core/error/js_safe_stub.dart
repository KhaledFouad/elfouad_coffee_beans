// Stub: على غير الويب بنرجّع null دايمًا
Object? getJsProp(Object o, String prop) => null;
