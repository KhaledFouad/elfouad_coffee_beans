// lib/Presentation/features/cashier_page/widgets/DrinkDialog.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:elfouad_coffee_beans/core/error/utils_error.dart';
import 'package:flutter/material.dart';

enum Serving { single, dbl }

class DrinkDialog extends StatefulWidget {
  final String drinkId;
  final Map<String, dynamic> drinkData;

  const DrinkDialog({
    super.key,
    required this.drinkId,
    required this.drinkData,
  });

  @override
  State<DrinkDialog> createState() => _DrinkDialogState();
}

class _DrinkDialogState extends State<DrinkDialog> {
  bool _busy = false;
  String? _fatal;
  int _qty = 1;

  // Serving (سنجل/دوبل) للتركي/اسبريسو فقط
  Serving _serving = Serving.single;

  // Complimentary (ضيافة)
  bool _isComplimentary = false;

  // Coffee Mix (مياه/لبن)
  bool get _isCoffeeMix => _name.trim() == 'كوفي ميكس';
  String _mix = 'water'; // water | milk

  // --------- Utilities ---------
  String _norm(String s) => s.replaceAll('ى', 'ي').trim();
  bool _isNum(dynamic v) =>
      v is num || double.tryParse(v?.toString() ?? '') != null;
  double _numOf(dynamic v, [double def = 0.0]) {
    if (v is num) return v.toDouble();
    return double.tryParse(v?.toString() ?? '') ?? def;
  }

  // --------- getters آمنة ---------
  String get _name => (widget.drinkData['name'] ?? '').toString();
  String get _image =>
      (widget.drinkData['image'] ?? 'assets/drinks.jpg').toString();
  String get _unit => (widget.drinkData['unit'] ?? 'cup').toString();

  double get _sellPriceBase => _numOf(widget.drinkData['sellPrice']);

  // ==== Spice option (Turkish only) ====
  bool _spiced = false;

  bool get _isTurkish {
    // توحيد ي/ى علشان اختلاف الكتابة
    final n = _norm(_name);
    return n == _norm('قهوة تركي');
  }

  Widget _toggleCard({
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    final selectedBg = const Color(0xFF543824); // بني أساسي
    final unselectedBg = Colors.brown.shade50;
    final selectedBorder = Colors.brown.shade700;
    final unselectedBorder = Colors.brown.shade100;
    final selectedText = Colors.white;
    final unselectedText = const Color(0xFF543824);

    return Container(
      decoration: BoxDecoration(
        color: value ? selectedBg : unselectedBg,
        border: Border.all(color: value ? selectedBorder : unselectedBorder),
        borderRadius: BorderRadius.circular(12),
      ),
      child: CheckboxListTile(
        value: value,
        onChanged: _busy ? null : (v) => onChanged(v ?? false),
        dense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12),
        controlAffinity: ListTileControlAffinity.leading,
        // نخلي لون النص يتغير مع التفعيل
        title: Text(
          title,
          style: TextStyle(
            color: value ? selectedText : unselectedText,
            fontWeight: FontWeight.w600,
            fontSize: 17,
          ),
        ),
        // نخلي علامة الصح ولون المربع واضحين فوق الخلفية البنية
        activeColor: Colors.white, // لون تعبئة مربع الـ checkbox وقت التفعيل
        checkColor: selectedBg, // لون علامة الصح
      ),
    );
  }

  double get _spicedCupCost =>
      _numOf(widget.drinkData['spicedCupCost'], _costPriceSingle);

  // تكلفة سنجل أساسية
  double get _costPriceSingle => _numOf(widget.drinkData['costPrice']);

  // حقول الدبل الجديدة
  double get _doublePrice => _numOf(widget.drinkData['doublePrice']);
  double get _doubleCostNew {
    // دعم اسمين محتملين: doubleCost أو doubleCostPrice
    final v = widget.drinkData['doubleCost'];
    if (_isNum(v)) return _numOf(v);
    return _numOf(widget.drinkData['doubleCostPrice']);
  }

  // استهلاك الدبل (لو متوفر)، غير كده هنضرب usedAmount × 2
  double get _doubleUsedAmount => _numOf(widget.drinkData['doubleUsedAmount']);

  // تكلفة الدوبل fallback قديم لو مفيش doubleCost
  double get _doubleCostFallback =>
      _numOf(widget.drinkData['doubleCostPrice'], _costPriceSingle * 2.0);

  // خصم الدبل القديم (لو احتجناه لسعر fallback)
  double get _doubleDiscount =>
      _numOf(widget.drinkData['doubleDiscount'], 10.0);

  bool get _supportsServingChoice =>
      _norm(_name) == _norm('قهوة تركي') ||
      _norm(_name) == _norm('قهوة اسبريسو');

  // أسعار الكوفي ميكس (اختياري)
  double get _coffeeMixUnitPrice {
    final mix = widget.drinkData['mixOptions'] as Map<String, dynamic>?;
    final water = _numOf(mix?['waterPrice'], 15);
    final milk = _numOf(mix?['milkPrice'], 25);
    return _mix == 'milk' ? milk : water;
  }

  // سعر الوحدة النهائي (يراعي الدبل بـ doublePrice إن وجد)
  double get _unitPriceEffective {
    if (_isComplimentary) return 0.0;
    if (_isCoffeeMix) return _coffeeMixUnitPrice;

    if (_supportsServingChoice && _serving == Serving.dbl) {
      // لو سعر دبل محدد نستخدمه، غير كده fallback للطريقة القديمة
      return _doublePrice > 0
          ? _doublePrice
          : (_sellPriceBase * 2.0) - _doubleDiscount;
    }
    return _sellPriceBase;
  }

  // تكلفة سنجل/دبل حسب القواعد الجديدة، وتراعي محوّج التركي
  double get _unitCostFinal {
    final isDouble = _supportsServingChoice && _serving == Serving.dbl;

    if (!isDouble) {
      // سنجل
      if (_isTurkish && _spiced) return _spicedCupCost;
      return _costPriceSingle;
    }

    // دبل
    if (_isTurkish) {
      if (_spiced) {
        // محوج + دبل: خُص تكلفته لو متاحة
        final spicedDoubleCupCost = _numOf(
          widget.drinkData['spicedDoubleCupCost'],
        );
        if (spicedDoubleCupCost > 0) return spicedDoubleCupCost;
        // fallback منطقي
        if (_spicedCupCost > 0) return _spicedCupCost * 2.0;
      }
      // تركي دبل غير محوج
      if (_doubleCostNew > 0) return _doubleCostNew;
      return _doubleCostFallback;
    }

    // اسبريسو (أو أي مشروب دبل تاني)
    if (_doubleCostNew > 0) return _doubleCostNew;
    return _doubleCostFallback;
  }

  double get _totalPrice => _unitPriceEffective * _qty;
  double get _totalCost => _unitCostFinal * _qty;

  Future<void> _commitSale() async {
    if (_name.isEmpty) {
      setState(() => _fatal = 'اسم المنتج غير موجود.');
      await showErrorDialog(context, _fatal!);
      return;
    }

    setState(() => _busy = true);
    try {
      final db = FirebaseFirestore.instance;

      // --- قراءة مدخلات الاستهلاك من بيانات المشروب ---
      final usedAmountRaw = widget.drinkData['usedAmount'];
      final usedAmount = _isNum(usedAmountRaw) ? _numOf(usedAmountRaw) : null;

      // لو الحجم دبل، استهلاك مختلف لو فيه doubleUsedAmount وإلا ×2
      final isDouble = _supportsServingChoice && _serving == Serving.dbl;
      final perUnitConsumption = (usedAmount == null || usedAmount <= 0)
          ? 0.0
          : (isDouble
                ? (_doubleUsedAmount > 0 ? _doubleUsedAmount : usedAmount * 2.0)
                : usedAmount);

      final totalConsumption = perUnitConsumption * _qty;

      // ممكن تبقى موجودة في الداتا عشان الربط المباشر
      final sourceBlendId = (widget.drinkData['sourceBlendId'] ?? '')
          .toString()
          .trim();

      // اسم بديل لو مفيش ID. هنستخدم اللي في الداتا أو أوڤررايد حسب الاسم
      final sourceBlendNameRaw = (widget.drinkData['sourceBlendName'] ?? '')
          .toString()
          .trim();

      // أوڤررايد أسماء المصادر لبعض المشروبات (بناءً على كلامك)
      const Map<String, String> sourceBlendOverrides = {
        'قهوة اسبريسو': 'توليفة اسبريسو',
        'شاي': 'شاي كيني',
        'شاى': 'شاي كيني',
      };

      String resolvedSourceBlendName = sourceBlendNameRaw.isNotEmpty
          ? sourceBlendNameRaw
          : (sourceBlendOverrides[_norm(_name)] ?? _name);

      // هنجهّز مرجع التوليفة لو هنخصم
      DocumentReference<Map<String, dynamic>>? blendRef;
      if (totalConsumption > 0) {
        if (sourceBlendId.isNotEmpty) {
          blendRef = db.collection('blends').doc(sourceBlendId);
        } else {
          // لو مفيش ID، ندور مرّة واحدة بالاسم (خارج الترانزاكشن)
          final byName = await db
              .collection('blends')
              .where('name', isEqualTo: resolvedSourceBlendName)
              .limit(1)
              .get();
          if (byName.docs.isNotEmpty) {
            blendRef = byName.docs.first.reference;
          } else {
            throw Exception(
              'مصدر الاستهلاك غير موجود: "$resolvedSourceBlendName"',
            );
          }
        }
      }

      // مرجع بيع جديد
      final saleRef = db.collection('sales').doc();

      await db.runTransaction((tx) async {
        // 1) خصم المخزون من التوليفات لو مطلوب
        if (blendRef != null) {
          final snap = await tx.get(blendRef);
          if (!snap.exists) {
            throw Exception('مصدر الاستهلاك غير موجود في المخزون.');
          }
          final data = snap.data()!;
          final currentStock = _numOf(data['stock']);
          if (currentStock < totalConsumption) {
            throw Exception(
              'المخزون غير كافي في "${data['name'] ?? resolvedSourceBlendName}"',
            );
          }

          // تحديث stock فقط (متوافق مع القواعد المقيدة)
          tx.update(blendRef, {'stock': currentStock - totalConsumption});
        }

        // 2) تسجّيل عملية البيع (اسم الحقل time = created_at حسب القواعد)
        final isComp = _isComplimentary;
        final unitCost = _unitCostFinal;
        final totalCost = unitCost * _qty;

        // لو ضيافة: سعر = 0 والإجمالي = 0 والربح = 0
        final unitPriceOut = isComp ? 0.0 : _unitPriceEffective;
        final totalPriceOut = isComp ? 0.0 : _totalPrice;
        final profitOut = isComp ? 0.0 : (totalPriceOut - totalCost);

        tx.set(saleRef, {
          'type': 'drink',
          'drinkId': widget.drinkId,
          'name': _name,
          'drinkName': _name,
          'image': _image,
          'unit': _unit,
          'serving': _supportsServingChoice
              ? (_serving == Serving.dbl ? 'double' : 'single')
              : 'single',
          'quantity': _qty,

          // === السعر والإجمالي والربح مكيّفين على الضيافة ===
          'unit_price': unitPriceOut,
          'total_price': totalPriceOut,
          'total_cost': totalCost,
          'profit_total': profitOut,

          // === التكاليف (لا تتأثر بالضيافة) ===
          'list_cost': _costPriceSingle,
          'unit_cost': unitCost,

          // توصيف إضافي
          'is_complimentary': isComp, // ✅ مفيد في التقارير والفلاتر
          // خيار المحوّج والـ cost basis كما هي
          'spiced': _isTurkish ? _spiced : false,
          'cost_basis': (_isTurkish && _spiced)
              ? (_supportsServingChoice && _serving == Serving.dbl
                    ? 'spicedDoubleCupCost'
                    : 'spicedCupCost')
              : (_supportsServingChoice && _serving == Serving.dbl
                    ? 'doubleCost'
                    : 'costPrice'),

          // الاستهلاك من المخزون (لو موجود)
          'consumption': (totalConsumption > 0)
              ? {
                  'sourceBlendId': blendRef?.id,
                  'sourceBlendName': resolvedSourceBlendName,
                  'usedAmountPerUnit': isDouble
                      ? (_doubleUsedAmount > 0
                            ? _doubleUsedAmount
                            : (usedAmount ?? 0.0) * 2.0)
                      : (usedAmount ?? 0.0),
                  'serving': _serving == Serving.dbl ? 'double' : 'single',
                  'totalConsumed': totalConsumption,
                }
              : null,

          'voided': false,
          'created_at': FieldValue.serverTimestamp(),
        });
      });

      if (!mounted) return;
      final nav = Navigator.of(context, rootNavigator: true);
      nav.pop();
      nav.pushNamedAndRemoveUntil('/', (r) => false);
    } catch (e, st) {
      logError(e, st);
      if (mounted) await showErrorDialog(context, e, st);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // منع تغطية الكيبورد + سكرول
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    return AnimatedPadding(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
      padding: EdgeInsets.only(bottom: bottomInset + 12),
      child: SafeArea(
        child: Dialog(
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 24,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: SingleChildScrollView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              padding: EdgeInsets.zero,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(18),
                    ),
                    child: Stack(
                      children: [
                        Image.asset(
                          _image,
                          height: 140,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                        Container(
                          height: 140,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.black.withOpacity(0.15),
                                Colors.black.withOpacity(0.55),
                              ],
                            ),
                          ),
                        ),
                        Positioned.fill(
                          child: Center(
                            child: Text(
                              _name,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 27,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Body
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        if (_supportsServingChoice) ...[
                          Align(
                            alignment: Alignment.center,
                            child: SegmentedButton<Serving>(
                              segments: const [
                                ButtonSegment(
                                  value: Serving.single,
                                  label: Text('سنجل'),
                                  icon: Icon(Icons.coffee_outlined),
                                ),
                                ButtonSegment(
                                  value: Serving.dbl,
                                  label: Text('دوبل'),
                                  icon: Icon(Icons.coffee),
                                ),
                              ],
                              selected: {_serving},
                              onSelectionChanged: _busy
                                  ? null
                                  : (s) => setState(() => _serving = s.first),
                              showSelectedIcon: false,
                            ),
                          ),
                          const SizedBox(height: 12),
                        ],

                        if (_isCoffeeMix) ...[
                          Align(
                            alignment: Alignment.center,
                            child: SegmentedButton<String>(
                              segments: const [
                                ButtonSegment(
                                  value: 'water',
                                  label: Text('مياه'),
                                  icon: Icon(Icons.water_drop_outlined),
                                ),
                                ButtonSegment(
                                  value: 'milk',
                                  label: Text('لبن'),
                                  icon: Icon(Icons.local_drink),
                                ),
                              ],
                              selected: {_mix},
                              onSelectionChanged: _busy
                                  ? null
                                  : (s) => setState(() => _mix = s.first),
                              showSelectedIcon: false,
                            ),
                          ),
                          const SizedBox(height: 12),
                        ],
                        // === محوّج + ضيافة جنب بعض ===
                        // === محوّج + ضيافة جنب بعض بنفس الديزاين ===
                        Row(
                          children: [
                            if (_isTurkish) ...[
                              Expanded(
                                child: _toggleCard(
                                  title: 'محوّج',
                                  value: _spiced, // ✅ ده بيتحكم في المحوّج
                                  onChanged: (v) => setState(() => _spiced = v),
                                ),
                              ),
                              const SizedBox(width: 12),
                            ],
                            Expanded(
                              child: _toggleCard(
                                title: 'ضيافة',
                                value: _isComplimentary,
                                onChanged: (v) =>
                                    setState(() => _isComplimentary = v),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        const SizedBox(height: 12),

                        // سعر الكوب
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'سعر الكوب',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              '${_unitPriceEffective.toStringAsFixed(2)} جم',
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        // Quantity stepper
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton.filledTonal(
                              onPressed: _busy
                                  ? null
                                  : () {
                                      if (_qty > 1) setState(() => _qty -= 1);
                                    },
                              icon: const Icon(Icons.remove),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                              ),
                              child: Text(
                                '$_qty',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            IconButton.filledTonal(
                              onPressed: _busy
                                  ? null
                                  : () => setState(() => _qty += 1),
                              icon: const Icon(Icons.add),
                            ),
                          ],
                        ),

                        const SizedBox(height: 12),

                        // إجمالي السعر
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.brown.shade50,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Colors.brown.shade100),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'الإجمالي',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                ),
                              ),
                              Text(
                                _totalPrice.toStringAsFixed(2),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),

                        if (_fatal != null) ...[
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.orange.shade50,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.orange.shade200),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(
                                  Icons.warning_amber,
                                  color: Colors.orange,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _fatal!,
                                    style: const TextStyle(
                                      color: Colors.orange,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),

                  const Divider(height: 1),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _busy
                                ? null
                                : () => Navigator.pop(context),
                            child: const Text(
                              'إلغاء',
                              style: TextStyle(
                                color: Color(0xFF543824),
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton(
                            style: ButtonStyle(
                              backgroundColor: WidgetStateProperty.all(
                                const Color(0xFF543824),
                              ),
                            ),
                            onPressed: _busy ? null : _commitSale,
                            child: _busy
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text(
                                    'تأكيد',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14,
                                    ),
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
